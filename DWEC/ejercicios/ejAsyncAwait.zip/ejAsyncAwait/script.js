const body = document.body

let multiplicar = (numero) => {
    for (let i = 1; i < 11; i++) {
        const p = document.createElement('p')
        p.textContent = `${numero} * ${i} = ${numero*i}`
        
        setTimeout(() => {
            body.appendChild(p)
        }, 1000*i);
    }
}


let num_incorrecto = (numero) => {
    const p = document.createElement('p')
    p.textContent = `El valor ${numero} no es correcto`
    body.append(p)
}


let mi_funcion = () => {
    return new Promise((resolve, reject) => {
        let num = document.getElementById('input').value
        if (num != '') {
            if (num >= 0 && num <= 10) {
                resolve(multiplicar(num))
            } else {
                reject(num_incorrecto(num))
            }
        }
    })
}



let miFuncionAsincrona = async () => {
    await mi_funcion()
}

miFuncionAsincrona()