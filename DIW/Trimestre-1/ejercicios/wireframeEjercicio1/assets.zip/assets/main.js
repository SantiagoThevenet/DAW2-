function menu(){
    let lista = document.getElementById('list')
    lista.classList.toggle('ocultar_mostrar')
}
